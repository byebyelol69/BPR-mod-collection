# wahooney_custom_properties_collection.py Copyright (C) 2021, Keith (Wahooney) Boshoff
#
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
from rna_prop_ui import PropertyPanel
from bpy.types import (Panel, Collection)

bl_info = {
    "name": "Collection Custom Properties Panel",
    "author": "DGIorio, Wahooney",
    "version": (1, 0),
    "blender": (2, 93, 0),
    "location": "Properties Panel > Collection Properties",
    "description": "Quick Access to Custom Properties on collections",
    "category": "Collections",
}

class CollectionButtonsPanel:
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "collection"

class COLLECTION_PT_collection_custom_props(CollectionButtonsPanel, PropertyPanel, Panel): 
    
    _context_path = "collection"
    _property_type = Collection

def register():
    bpy.utils.register_class(COLLECTION_PT_collection_custom_props)


def unregister():
    bpy.utils.unregister_class(COLLECTION_PT_collection_custom_props)


if __name__ == "__main__":
    register()
